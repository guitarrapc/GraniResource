Community Chocolatey DSC Resource - @lawrencegripper
=============================

This resource is aimed at getting and installing packages from the choco gallery. Currently early beta version.  

The resource takes the name of the package and will then install that package. 

See list of packages here: https://chocolatey.org/packages/git.install
